import React, { Component } from "react";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";

import * as actions from "./actions/actions.js";

class App extends Component {
  constructor(props){
    super();
    this.init.bind(this);
  }

  async init() {
    await this.props.actions.fetchInit();
    console.log(this.props.coupons);
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <div>
            <p>Hello World!</p>
            <p>{this.props.coupons}</p>
          </div>
        </header>
      </div>
    );
  }
}

export default connect(
  null , 
  (dispatch) => ({
      "actions": bindActionCreators(actions , dispatch)
  })
)(App);
