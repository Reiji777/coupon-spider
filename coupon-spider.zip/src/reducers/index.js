/* eslint-disable default-case */
const defaultObj = { 
    "coupons": {}
};

export default (state = defaultObj, action) => {
    switch (action.type) {
        case "INIT":
            return {
                ...state,
                "coupons": action.coupons
            }
    }
}