import db from "../firebase"

export const fetchInit = () => async (dispatch) => {
    const coupons = await db.collection("test")
    .get()
    .then(querySnapshot => querySnapshot);

    dispatch({"type" : "INIT" , coupons})
}
